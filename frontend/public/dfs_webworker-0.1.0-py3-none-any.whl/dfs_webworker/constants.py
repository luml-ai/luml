PRODUCER = "dataforce.studio"
TABULAR_CLASSIFICATION = "tabular_classification"
TABULAR_REGRESSION = "tabular_regression"
